﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Khumalo_st10243676_Recipe_POE_Part__1
{
    internal class Ingredient
    {
        private int noIngredients; //field
        private string nameIngr; //field
        private string unitMeasure; //field
        private int quantity;  //field
        private string descrip;
        private int noSteps;



        public int NoIngredients  //property
        {
            get { return noIngredients; }  //get method
            set { noIngredients = value; } //set method
        }

        public string NameIngr //property
        {

            get { return nameIngr; } //get method 
            set { nameIngr = value; } //set method
        }

        public string UnitMeasure
        {
            get { return unitMeasure; } //get method
            set { unitMeasure = value; } //set method
        }
        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }
        


        public int NoSteps
        {
            get { return noSteps; }
            set { noSteps = value; }

        }
        public string Descrip
        {
            get { return descrip; }
            set { descrip = value; }
        }








    }



}


