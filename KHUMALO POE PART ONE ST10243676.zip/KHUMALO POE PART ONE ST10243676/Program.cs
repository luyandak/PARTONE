﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace Khumalo_st10243676_Recipe_POE_Part__1
{
    internal class Program
    {

        //declaring arrays to store ingredients and steps

        static Ingredient[] arrIngredient = new Ingredient[3];
        static Ingredient[] arrDescription=new Ingredient[2];

        
        static int numbInArray = 0;
   
         //Creating objects for external class,to access variables within the classes.
        static Ingredient bjo = new Ingredient();



        static void Main(string[] args)
        {



            //Calling methods in main class.
            userInputIngredients();
            Display();


        

            for (int i = 0; i < arrIngredient.Length; i++)
            {
                
                //user prompt
                Console.WriteLine("SELECT 'YES' OR 'NO' TO SELECT  A COMMAND (SCALE RECIPE, RESET RECIPE, CLEAR RECIPE, EXIT APPLICATION: " +
                    "\n1. yes" +
                    "\n2. no ");

                int Usereresponce = Convert.ToInt32(Console.ReadLine());

                if (Usereresponce == 1)
                {
                    Console.WriteLine("SELECT  A COMMAND " +
                        "\n1. SCALE" +
                        "\n2. RESET" +
                        "\n3. CLEAR");
                    int comand = Convert.ToInt32(Console.ReadLine());
                    if (comand == 1)
                    {
                        RecipeScaler();
                    }
                    else if (comand == 2)
                    {
                        Delete();
                    }
                    else if (comand == 3)
                    {
                       ValueReset();
                    }
                }
            }

        }
        static void RecipeScaler () //method to scale the  Ingredients of recipe by 0,5,2 or 3.

        { 
            Console.WriteLine("\nScaled Recipe (factor {0}):\n");

            for (int i = 0; i < arrIngredient.Length; i++)
            {
                Console.WriteLine("- {0} {1} of {2}",arrIngredient , arrDescription[i]) ;
            }
        }





    

        

         public static void userInputIngredients()    //method to prompt user for ingredients
                                                                                      
        {
            int i;
            Console.ForegroundColor = ConsoleColor.Yellow; //Gives console colour
            Console.WriteLine("RECIPE APPLICATION----------------------------------------"+"\n");
            Console.WriteLine("Enter the number of ingredients you will use:");
            bjo.NoIngredients = Convert.ToInt32(Console.ReadLine());

            for (i = 0; i < bjo.NoIngredients; i++)
            {

                Console.WriteLine("Enter the name of Ingredient:");
                bjo.NameIngr = Console.ReadLine();

                Console.WriteLine("Enter the quantity of " + bjo.NameIngr + "s used");
                bjo.Quantity = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the unit of measurement that will be used:" + "\n");
                bjo.UnitMeasure = Console.ReadLine();
                ;







                Console.WriteLine("Enter the number of steps used in recipe:");
                bjo.NoSteps = Convert.ToInt32(Console.ReadLine());
                for (i = 0; i < bjo.NoSteps; i++)
                {


                    Console.WriteLine("Enter a description of each step");
                    bjo.Descrip = Console.ReadLine();
                    Console.WriteLine(" ");
                    arrDescription[numbInArray] = bjo;
                    numbInArray++;



                }

            }
        }




        public static void Display()  //method to display recipe to user.
        {
            Console.ForegroundColor = ConsoleColor.Blue; //Gives console colour
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < arrIngredient.Length; i++) //for loop for displaying
            {



                {
                    Console.WriteLine("- {0} {1} of {2}", arrIngredient[i]); //displays recipe


                    Console.WriteLine("\nSteps:");
                    for (int m=0; m < arrDescription.Length; m++)
                    {
                        Console.WriteLine("{0}. {1}", m+ 1, arrDescription[i]);
                    }

                }
            }
        }
        public static void ValueReset() //method to reset array values.
        {

           
            
                Console.WriteLine("\nReset Recipe:\n");
                Display();
            }
        
        public static void Delete() //method to delete recipe
        {
            int confirmClear;
            int clearConfirmation;
            Console.WriteLine("Do you want to clear the recipe,to enter a new recipe?"+"/n"+
                                    "1)YES"+"/n"
                                    +"2)NO");


            confirmClear=Convert.ToInt32(Console.ReadLine());       

            if(confirmClear==1)
            {
                Console.WriteLine("Are you sure that you want to clear recipe?"+"/n"
                                 +"1}YES"+"/n"
                                 +"2)NO");

                clearConfirmation=Convert.ToInt32(Console.ReadLine());

                if(clearConfirmation==1)
                {
                    
                        arrIngredient = null;
                       arrDescription = null;
                        
                        Console.WriteLine("\nRecipe cleared.");
                    }
                
            
                else if (clearConfirmation == 2)
                {
                    Console.WriteLine("");
                }
               
                

            }
           

        }
    }



}
